# Home Printing Backend

This is a Node.js + Express backend for a home printing business.

## Setup

```bash
# Install dependencies
npm install

# Create a .env file in the root directory with the following variables:
MONGO_URI=your_mongodb_connection_string
PORT=10000
JWT_SECRET=supersecretjwt
UPLOAD_DIR=./uploads
SENDGRID_SMTP_USER=you@example.com
SENDGRID_SMTP_PASS=your_sendgrid_password
TWILIO_ACCOUNT_SID=optional
TWILIO_AUTH_TOKEN=optional
TWILIO_PHONE_NUMBER=optional
BUSINESS_UPI_ID=yourupi@bank
BUSINESS_NAME=YourPrintShop
BASE_URL=https://your-api.onrender.com

# Run in development mode
npm run dev

# Run in production mode
npm start
```

## Deployment

Deploy this project on Render or any Node.js hosting platform.
