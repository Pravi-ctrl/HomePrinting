import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { OrderProvider } from './contexts/OrderContext';
import Navigation from './components/Navigation';
import LandingPage from './pages/LandingPage';
import UploadPage from './pages/UploadPage';
import PricingPage from './pages/PricingPage';
import OrderConfirmation from './pages/OrderConfirmation';
import SellerDashboard from './pages/SellerDashboard';
import OrderTracking from './pages/OrderTracking';
import AboutContact from './pages/AboutContact';

function App() {
  return (
    <OrderProvider>
      <Router>
        <div className="min-h-screen bg-white">
          <Navigation />
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/upload" element={<UploadPage />} />
            <Route path="/pricing" element={<PricingPage />} />
            <Route path="/confirmation" element={<OrderConfirmation />} />
            <Route path="/dashboard" element={<SellerDashboard />} />
            <Route path="/track" element={<OrderTracking />} />
            <Route path="/about" element={<AboutContact />} />
          </Routes>
          <Toaster position="top-right" />
        </div>
      </Router>
    </OrderProvider>
  );
}

export default App;