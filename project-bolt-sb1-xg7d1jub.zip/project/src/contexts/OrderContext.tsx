import React, { createContext, useContext, useState, ReactNode } from 'react';

export interface PrintingOptions {
  paperSize: 'A4' | 'A3' | 'Letter';
  colorMode: 'color' | 'bw';
  quantity: number;
  sides: 'single' | 'double';
}

export interface OrderItem {
  id: string;
  name: string;
  file: File;
  options: PrintingOptions;
  price: number;
  status: 'pending' | 'printing' | 'completed' | 'ready';
  createdAt: Date;
}

interface OrderContextType {
  orders: OrderItem[];
  currentOrder: Partial<OrderItem> | null;
  addOrder: (order: OrderItem) => void;
  updateOrderStatus: (id: string, status: OrderItem['status']) => void;
  setCurrentOrder: (order: Partial<OrderItem>) => void;
  clearCurrentOrder: () => void;
}

const OrderContext = createContext<OrderContextType | undefined>(undefined);

export const useOrder = () => {
  const context = useContext(OrderContext);
  if (!context) {
    throw new Error('useOrder must be used within OrderProvider');
  }
  return context;
};

export const OrderProvider = ({ children }: { children: ReactNode }) => {
  const [orders, setOrders] = useState<OrderItem[]>([]);
  const [currentOrder, setCurrentOrderState] = useState<Partial<OrderItem> | null>(null);

  const addOrder = (order: OrderItem) => {
    setOrders(prev => [...prev, order]);
  };

  const updateOrderStatus = (id: string, status: OrderItem['status']) => {
    setOrders(prev => 
      prev.map(order => 
        order.id === id ? { ...order, status } : order
      )
    );
  };

  const setCurrentOrder = (order: Partial<OrderItem>) => {
    setCurrentOrderState(order);
  };

  const clearCurrentOrder = () => {
    setCurrentOrderState(null);
  };

  return (
    <OrderContext.Provider value={{
      orders,
      currentOrder,
      addOrder,
      updateOrderStatus,
      setCurrentOrder,
      clearCurrentOrder
    }}>
      {children}
    </OrderContext.Provider>
  );
};