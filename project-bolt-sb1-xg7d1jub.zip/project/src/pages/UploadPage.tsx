import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useDropzone } from 'react-dropzone';
import { Upload, File, X, Eye, Settings } from 'lucide-react';
import toast from 'react-hot-toast';
import { useOrder, PrintingOptions } from '../contexts/OrderContext';

const UploadPage = () => {
  const navigate = useNavigate();
  const { setCurrentOrder } = useOrder();
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [previewFile, setPreviewFile] = useState<File | null>(null);
  const [options, setOptions] = useState<PrintingOptions>({
    paperSize: 'A4',
    colorMode: 'bw',
    quantity: 1,
    sides: 'single'
  });

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: {
      'application/pdf': ['.pdf'],
      'application/msword': ['.doc'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
      'image/jpeg': ['.jpg', '.jpeg'],
      'image/png': ['.png']
    },
    onDrop: (acceptedFiles) => {
      setUploadedFiles(prev => [...prev, ...acceptedFiles]);
      toast.success(`${acceptedFiles.length} file(s) uploaded successfully!`);
    }
  });

  const removeFile = (index: number) => {
    setUploadedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const calculatePrice = () => {
    const basePrice = options.colorMode === 'color' ? 5 : 2;
    const sizeMultiplier = options.paperSize === 'A3' ? 1.5 : 1;
    const sidesMultiplier = options.sides === 'double' ? 1.8 : 1;
    
    return uploadedFiles.reduce((total, file) => {
      const estimatedPages = Math.ceil(file.size / 50000); // Rough estimate
      return total + (estimatedPages * basePrice * sizeMultiplier * sidesMultiplier * options.quantity);
    }, 0);
  };

  const proceedToPayment = () => {
    if (uploadedFiles.length === 0) {
      toast.error('Please upload at least one file');
      return;
    }

    const totalPrice = calculatePrice();
    setCurrentOrder({
      file: uploadedFiles[0], // For demo, using first file
      name: uploadedFiles[0].name,
      options,
      price: totalPrice
    });
    navigate('/pricing');
  };

  const getFileIcon = (file: File) => {
    const type = file.type;
    if (type.includes('pdf')) return '📄';
    if (type.includes('word') || type.includes('document')) return '📝';
    if (type.includes('image')) return '🖼️';
    return '📁';
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Upload Your Files</h1>
            <p className="text-xl text-gray-600">
              Upload documents and customize your printing preferences
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Upload Section */}
            <div className="lg:col-span-2 space-y-6">
              <div className="bg-white rounded-xl shadow-lg p-8">
                <h2 className="text-2xl font-semibold text-gray-900 mb-6 flex items-center">
                  <Upload className="h-6 w-6 mr-2 text-blue-600" />
                  Upload Files
                </h2>
                
                <div
                  {...getRootProps()}
                  className={`border-2 border-dashed rounded-xl p-12 text-center transition-colors cursor-pointer ${
                    isDragActive 
                      ? 'border-blue-500 bg-blue-50' 
                      : 'border-gray-300 hover:border-blue-400 hover:bg-blue-50'
                  }`}
                >
                  <input {...getInputProps()} />
                  <Upload className="h-16 w-16 mx-auto text-gray-400 mb-4" />
                  <p className="text-xl font-semibold text-gray-700 mb-2">
                    {isDragActive ? 'Drop files here' : 'Drag & drop files here'}
                  </p>
                  <p className="text-gray-500 mb-4">or click to browse</p>
                  <p className="text-sm text-gray-400">
                    Supported formats: PDF, DOCX, JPG, PNG (Max 10MB per file)
                  </p>
                </div>
              </div>

              {/* Uploaded Files */}
              {uploadedFiles.length > 0 && (
                <div className="bg-white rounded-xl shadow-lg p-8">
                  <h3 className="text-xl font-semibold text-gray-900 mb-6">Uploaded Files</h3>
                  <div className="space-y-3">
                    {uploadedFiles.map((file, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                      >
                        <div className="flex items-center space-x-3">
                          <span className="text-2xl">{getFileIcon(file)}</span>
                          <div>
                            <p className="font-medium text-gray-900">{file.name}</p>
                            <p className="text-sm text-gray-500">
                              {(file.size / 1024 / 1024).toFixed(2)} MB
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => setPreviewFile(file)}
                            className="p-2 text-gray-400 hover:text-blue-600 transition-colors"
                          >
                            <Eye className="h-5 w-5" />
                          </button>
                          <button
                            onClick={() => removeFile(index)}
                            className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                          >
                            <X className="h-5 w-5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Options Sidebar */}
            <div className="bg-white rounded-xl shadow-lg p-8 h-fit">
              <h3 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
                <Settings className="h-5 w-5 mr-2 text-blue-600" />
                Printing Options
              </h3>
              
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Paper Size
                  </label>
                  <select
                    value={options.paperSize}
                    onChange={(e) => setOptions({ ...options, paperSize: e.target.value as PrintingOptions['paperSize'] })}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="A4">A4</option>
                    <option value="A3">A3 (+50%)</option>
                    <option value="Letter">Letter</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Print Mode
                  </label>
                  <div className="space-y-2">
                    <label className="flex items-center">
                      <input
                        type="radio"
                        value="bw"
                        checked={options.colorMode === 'bw'}
                        onChange={(e) => setOptions({ ...options, colorMode: e.target.value as PrintingOptions['colorMode'] })}
                        className="text-blue-600 focus:ring-blue-500"
                      />
                      <span className="ml-2">Black & White (₹2/page)</span>
                    </label>
                    <label className="flex items-center">
                      <input
                        type="radio"
                        value="color"
                        checked={options.colorMode === 'color'}
                        onChange={(e) => setOptions({ ...options, colorMode: e.target.value as PrintingOptions['colorMode'] })}
                        className="text-blue-600 focus:ring-blue-500"
                      />
                      <span className="ml-2">Color (₹5/page)</span>
                    </label>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Printing Sides
                  </label>
                  <select
                    value={options.sides}
                    onChange={(e) => setOptions({ ...options, sides: e.target.value as PrintingOptions['sides'] })}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="single">Single Side</option>
                    <option value="double">Double Side (-20%)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Quantity
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="100"
                    value={options.quantity}
                    onChange={(e) => setOptions({ ...options, quantity: parseInt(e.target.value) })}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                {uploadedFiles.length > 0 && (
                  <div className="border-t pt-6">
                    <div className="bg-blue-50 p-4 rounded-lg mb-4">
                      <div className="flex justify-between items-center">
                        <span className="text-gray-700 font-medium">Estimated Cost:</span>
                        <span className="text-2xl font-bold text-blue-600">₹{calculatePrice()}</span>
                      </div>
                      <p className="text-xs text-gray-500 mt-1">
                        *Final price may vary based on actual page count
                      </p>
                    </div>
                    
                    <button
                      onClick={proceedToPayment}
                      className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors shadow-lg hover:shadow-xl transform hover:-translate-y-1 duration-200"
                    >
                      Proceed to Payment
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default UploadPage;