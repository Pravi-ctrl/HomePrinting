import React from 'react';
import { motion } from 'framer-motion';
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  Award, 
  Users, 
  Printer, 
  Shield,
  Star,
  CheckCircle
} from 'lucide-react';

const AboutContact = () => {
  const features = [
    {
      icon: Award,
      title: 'Premium Quality',
      description: 'High-resolution printing with professional-grade equipment'
    },
    {
      icon: Clock,
      title: 'Fast Turnaround',
      description: 'Most orders ready within 2-4 hours of placement'
    },
    {
      icon: Shield,
      title: 'Secure & Private',
      description: 'Your documents are handled with complete confidentiality'
    },
    {
      icon: Users,
      title: 'Expert Support',
      description: '24/7 customer support for all your printing needs'
    }
  ];

  const testimonials = [
    {
      name: 'Sarah Johnson',
      rating: 5,
      text: 'Excellent service! My documents were printed perfectly and ready faster than expected.'
    },
    {
      name: 'Michael Chen',
      rating: 5,
      text: 'Very convenient online ordering system. Great quality prints at competitive prices.'
    },
    {
      name: 'Emily Davis',
      rating: 5,
      text: 'Professional service with quick turnaround. Highly recommend for all printing needs!'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 to-orange-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              About <span className="text-blue-600">PrintEase</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              We're a modern printing service dedicated to making document printing 
              simple, fast, and reliable. Upload, pay, and pickup - it's that easy!
            </p>
          </motion.div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Story</h2>
              <div className="space-y-4 text-gray-600 leading-relaxed">
                <p>
                  Founded in 2020, PrintEase was born from a simple idea: printing should be 
                  convenient, affordable, and hassle-free. We noticed that traditional printing 
                  services were often slow, expensive, or required multiple trips.
                </p>
                <p>
                  Our innovative online platform allows customers to upload documents from 
                  anywhere, customize their printing preferences, pay securely, and receive 
                  notifications when their orders are ready for pickup.
                </p>
                <p>
                  Today, we've served over 500 customers and printed more than 10,000 documents, 
                  always maintaining our commitment to quality, speed, and excellent customer service.
                </p>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="relative"
            >
              <div className="bg-blue-600 rounded-2xl p-8 text-white">
                <div className="grid grid-cols-2 gap-6 text-center">
                  <div>
                    <div className="text-3xl font-bold mb-2">500+</div>
                    <div className="text-blue-100">Happy Customers</div>
                  </div>
                  <div>
                    <div className="text-3xl font-bold mb-2">10K+</div>
                    <div className="text-blue-100">Documents Printed</div>
                  </div>
                  <div>
                    <div className="text-3xl font-bold mb-2">99.9%</div>
                    <div className="text-blue-100">Customer Satisfaction</div>
                  </div>
                  <div>
                    <div className="text-3xl font-bold mb-2">2-4h</div>
                    <div className="text-blue-100">Average Turnaround</div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Why Choose PrintEase?</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              We combine cutting-edge technology with reliable service to deliver 
              the best printing experience.
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-white rounded-xl p-6 shadow-lg text-center"
              >
                <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <feature.icon className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{feature.title}</h3>
                <p className="text-gray-600 leading-relaxed">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl font-bold text-gray-900 mb-4">What Our Customers Say</h2>
            <p className="text-xl text-gray-600">
              Don't just take our word for it - see what our customers have to say!
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-gray-50 rounded-xl p-6"
              >
                <div className="flex items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-700 mb-4 italic">"{testimonial.text}"</p>
                <p className="font-semibold text-gray-900">- {testimonial.name}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-gradient-to-br from-blue-600 to-orange-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl font-bold text-white mb-4">Get in Touch</h2>
            <p className="text-xl text-white/90">
              Have questions? Need help with your order? We're here to help!
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Information */}
            <div className="space-y-8">
              <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6">
                <h3 className="text-xl font-semibold text-white mb-6">Contact Information</h3>
                <div className="space-y-4">
                  <div className="flex items-center text-white/90">
                    <MapPin className="h-5 w-5 mr-3 text-white" />
                    <div>
                      <p className="font-medium">Address</p>
                      <p className="text-sm">123 Main Street, City Center, Ground Floor</p>
                      <p className="text-sm">Near ABC Mall, Postal Code 12345</p>
                    </div>
                  </div>
                  <div className="flex items-center text-white/90">
                    <Phone className="h-5 w-5 mr-3 text-white" />
                    <div>
                      <p className="font-medium">Phone</p>
                      <p className="text-sm">+91 12345 67890</p>
                      <p className="text-sm">Available 24/7 for support</p>
                    </div>
                  </div>
                  <div className="flex items-center text-white/90">
                    <Mail className="h-5 w-5 mr-3 text-white" />
                    <div>
                      <p className="font-medium">Email</p>
                      <p className="text-sm">support@printease.com</p>
                      <p className="text-sm">We reply within 1 hour</p>
                    </div>
                  </div>
                  <div className="flex items-center text-white/90">
                    <Clock className="h-5 w-5 mr-3 text-white" />
                    <div>
                      <p className="font-medium">Business Hours</p>
                      <p className="text-sm">Monday - Saturday: 9:00 AM - 7:00 PM</p>
                      <p className="text-sm">Sunday: 10:00 AM - 5:00 PM</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6">
              <h3 className="text-xl font-semibold text-white mb-6">Send us a Message</h3>
              <form className="space-y-4">
                <div>
                  <input
                    type="text"
                    placeholder="Your Name"
                    className="w-full px-4 py-3 bg-white/20 border border-white/30 rounded-lg text-white placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-white/50"
                  />
                </div>
                <div>
                  <input
                    type="email"
                    placeholder="Your Email"
                    className="w-full px-4 py-3 bg-white/20 border border-white/30 rounded-lg text-white placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-white/50"
                  />
                </div>
                <div>
                  <input
                    type="text"
                    placeholder="Subject"
                    className="w-full px-4 py-3 bg-white/20 border border-white/30 rounded-lg text-white placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-white/50"
                  />
                </div>
                <div>
                  <textarea
                    rows={4}
                    placeholder="Your Message"
                    className="w-full px-4 py-3 bg-white/20 border border-white/30 rounded-lg text-white placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-white/50 resize-none"
                  ></textarea>
                </div>
                <button
                  type="submit"
                  className="w-full bg-white text-blue-600 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors shadow-lg hover:shadow-xl transform hover:-translate-y-1 duration-200"
                >
                  Send Message
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Map Section (Placeholder) */}
      <section className="py-20 bg-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">Find Us</h2>
            <div className="bg-gray-300 rounded-xl h-96 flex items-center justify-center">
              <div className="text-center">
                <MapPin className="h-16 w-16 text-gray-500 mx-auto mb-4" />
                <p className="text-lg font-semibold text-gray-700">Interactive Map</p>
                <p className="text-gray-600">123 Main Street, City Center</p>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default AboutContact;