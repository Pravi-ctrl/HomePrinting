import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Package, Clock, Printer, CheckCircle, MapPin, Phone, Mail } from 'lucide-react';
import { useOrder } from '../contexts/OrderContext';

const OrderTracking = () => {
  const { orders } = useOrder();
  const [orderId, setOrderId] = useState('');
  const [searchedOrder, setSearchedOrder] = useState(null);

  const handleSearch = () => {
    if (!orderId.trim()) return;
    
    const order = orders.find(o => o.id.toLowerCase() === orderId.toLowerCase());
    setSearchedOrder(order || 'not_found');
  };

  const getStatusSteps = (currentStatus: string) => {
    const steps = [
      { key: 'pending', label: 'Order Received', icon: Package },
      { key: 'printing', label: 'Printing in Progress', icon: Printer },
      { key: 'completed', label: 'Print Completed', icon: CheckCircle },
      { key: 'ready', label: 'Ready for Pickup', icon: CheckCircle }
    ];

    const statusOrder = ['pending', 'printing', 'completed', 'ready'];
    const currentIndex = statusOrder.indexOf(currentStatus);

    return steps.map((step, index) => ({
      ...step,
      completed: index <= currentIndex,
      active: index === currentIndex
    }));
  };

  const getStatusMessage = (status: string) => {
    const messages = {
      pending: 'Your order has been received and is being reviewed.',
      printing: 'Your documents are currently being printed.',
      completed: 'Your documents have been printed successfully.',
      ready: 'Your order is ready for pickup! Please bring your order ID.'
    };
    return messages[status as keyof typeof messages] || 'Status unknown';
  };

  const getEstimatedTime = (status: string) => {
    const times = {
      pending: '15-30 minutes',
      printing: '30-60 minutes', 
      completed: '5-10 minutes',
      ready: 'Ready now'
    };
    return times[status as keyof typeof times] || 'Unknown';
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Track Your Order</h1>
            <p className="text-xl text-gray-600">
              Enter your order ID to get real-time status updates
            </p>
          </div>

          {/* Search Box */}
          <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
            <div className="max-w-md mx-auto">
              <div className="flex">
                <input
                  type="text"
                  value={orderId}
                  onChange={(e) => setOrderId(e.target.value.toUpperCase())}
                  placeholder="Enter Order ID (e.g., ABC12345)"
                  className="flex-1 border border-gray-300 rounded-l-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 text-center font-mono text-lg"
                  onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                />
                <button
                  onClick={handleSearch}
                  className="bg-blue-600 text-white px-6 py-3 rounded-r-lg hover:bg-blue-700 transition-colors"
                >
                  <Search className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>

          {/* Search Results */}
          {searchedOrder && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4 }}
            >
              {searchedOrder === 'not_found' ? (
                <div className="bg-white rounded-xl shadow-lg p-8 text-center">
                  <div className="text-red-500 mb-4">
                    <Package className="h-16 w-16 mx-auto opacity-50" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Order Not Found</h3>
                  <p className="text-gray-600 mb-6">
                    We couldn't find an order with ID: <strong>{orderId}</strong>
                  </p>
                  <div className="text-sm text-gray-500 space-y-2">
                    <p>Please check that you've entered the correct Order ID.</p>
                    <p>Order IDs are case-sensitive and usually 8 characters long.</p>
                  </div>
                </div>
              ) : (
                <div className="space-y-6">
                  {/* Order Info */}
                  <div className="bg-white rounded-xl shadow-lg p-8">
                    <div className="text-center mb-8">
                      <h2 className="text-2xl font-semibold text-gray-900 mb-2">Order #{searchedOrder.id}</h2>
                      <p className="text-gray-600">
                        Placed on {searchedOrder.createdAt.toLocaleDateString()}
                      </p>
                    </div>

                    <div className="grid md:grid-cols-2 gap-8">
                      <div>
                        <h3 className="font-semibold text-gray-900 mb-4">Order Details</h3>
                        <div className="space-y-3">
                          <div className="flex justify-between">
                            <span className="text-gray-600">File:</span>
                            <span className="font-medium">{searchedOrder.name}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Paper Size:</span>
                            <span className="font-medium">{searchedOrder.options.paperSize}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Mode:</span>
                            <span className="font-medium">
                              {searchedOrder.options.colorMode === 'color' ? 'Color' : 'Black & White'}
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-gray-600">Quantity:</span>
                            <span className="font-medium">{searchedOrder.options.quantity}</span>
                          </div>
                          <div className="flex justify-between text-lg font-semibold pt-2 border-t">
                            <span>Total:</span>
                            <span className="text-blue-600">₹{searchedOrder.price}</span>
                          </div>
                        </div>
                      </div>

                      <div>
                        <h3 className="font-semibold text-gray-900 mb-4">Current Status</h3>
                        <div className="bg-blue-50 rounded-lg p-4">
                          <div className="flex items-center mb-3">
                            <div className={`w-3 h-3 rounded-full mr-3 ${
                              searchedOrder.status === 'ready' ? 'bg-green-500' : 
                              searchedOrder.status === 'completed' ? 'bg-purple-500' :
                              searchedOrder.status === 'printing' ? 'bg-blue-500' : 'bg-yellow-500'
                            }`}></div>
                            <span className="font-semibold">
                              {getStatusSteps(searchedOrder.status).find(step => step.active)?.label}
                            </span>
                          </div>
                          <p className="text-sm text-gray-700 mb-2">
                            {getStatusMessage(searchedOrder.status)}
                          </p>
                          <p className="text-sm text-blue-600 font-medium">
                            Estimated time: {getEstimatedTime(searchedOrder.status)}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Progress Tracker */}
                  <div className="bg-white rounded-xl shadow-lg p-8">
                    <h3 className="text-xl font-semibold text-gray-900 mb-8 text-center">Order Progress</h3>
                    <div className="relative">
                      <div className="flex justify-between items-center">
                        {getStatusSteps(searchedOrder.status).map((step, index) => {
                          const Icon = step.icon;
                          return (
                            <div key={step.key} className="flex flex-col items-center relative z-10">
                              <div className={`w-12 h-12 rounded-full flex items-center justify-center mb-3 transition-colors ${
                                step.completed 
                                  ? 'bg-blue-600 text-white' 
                                  : step.active 
                                    ? 'bg-blue-100 text-blue-600 ring-4 ring-blue-200' 
                                    : 'bg-gray-100 text-gray-400'
                              }`}>
                                <Icon className="h-6 w-6" />
                              </div>
                              <span className={`text-sm font-medium text-center px-2 ${
                                step.completed || step.active ? 'text-gray-900' : 'text-gray-400'
                              }`}>
                                {step.label}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                      
                      {/* Progress Line */}
                      <div className="absolute top-6 left-6 right-6 h-0.5 bg-gray-200 -z-10">
                        <div 
                          className="h-full bg-blue-600 transition-all duration-500"
                          style={{ 
                            width: `${(getStatusSteps(searchedOrder.status).filter(step => step.completed).length - 1) * 33.33}%` 
                          }}
                        ></div>
                      </div>
                    </div>
                  </div>

                  {/* Pickup Information */}
                  {searchedOrder.status === 'ready' && (
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.3 }}
                      className="bg-green-50 border border-green-200 rounded-xl p-8"
                    >
                      <h3 className="text-xl font-semibold text-green-800 mb-6 text-center">
                        🎉 Your Order is Ready for Pickup!
                      </h3>
                      <div className="grid md:grid-cols-2 gap-6">
                        <div className="space-y-4">
                          <div className="flex items-start">
                            <MapPin className="h-5 w-5 text-green-600 mr-3 mt-1 flex-shrink-0" />
                            <div>
                              <p className="font-medium text-green-800">Pickup Location</p>
                              <p className="text-sm text-green-700">
                                123 Main Street<br />
                                City Center, Ground Floor<br />
                                Near ABC Mall
                              </p>
                            </div>
                          </div>
                        </div>
                        <div className="space-y-4">
                          <div className="flex items-start">
                            <Clock className="h-5 w-5 text-green-600 mr-3 mt-1 flex-shrink-0" />
                            <div>
                              <p className="font-medium text-green-800">Pickup Hours</p>
                              <p className="text-sm text-green-700">
                                Monday - Saturday: 9:00 AM - 7:00 PM<br />
                                Sunday: 10:00 AM - 5:00 PM
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="mt-6 p-4 bg-green-100 rounded-lg">
                        <p className="text-sm text-green-800 font-medium">
                          📋 Important: Please bring your Order ID ({searchedOrder.id}) when picking up your documents.
                        </p>
                      </div>
                    </motion.div>
                  )}

                  {/* Contact Support */}
                  <div className="bg-white rounded-xl shadow-lg p-8">
                    <h3 className="text-xl font-semibold text-gray-900 mb-6 text-center">Need Help?</h3>
                    <div className="grid md:grid-cols-2 gap-6">
                      <div className="flex items-center p-4 bg-blue-50 rounded-lg">
                        <Phone className="h-6 w-6 text-blue-600 mr-3" />
                        <div>
                          <p className="font-medium text-gray-900">Call Us</p>
                          <p className="text-sm text-gray-600">+91 12345 67890</p>
                        </div>
                      </div>
                      <div className="flex items-center p-4 bg-blue-50 rounded-lg">
                        <Mail className="h-6 w-6 text-blue-600 mr-3" />
                        <div>
                          <p className="font-medium text-gray-900">Email Support</p>
                          <p className="text-sm text-gray-600">support@printease.com</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          )}

          {/* Demo Orders */}
          {!searchedOrder && orders.length > 0 && (
            <div className="bg-white rounded-xl shadow-lg p-8">
              <h3 className="text-xl font-semibold text-gray-900 mb-6">Recent Orders</h3>
              <div className="space-y-4">
                {orders.slice(-3).map((order) => (
                  <div 
                    key={order.id}
                    className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                    onClick={() => {
                      setOrderId(order.id);
                      setSearchedOrder(order);
                    }}
                  >
                    <div>
                      <p className="font-medium text-gray-900">Order #{order.id}</p>
                      <p className="text-sm text-gray-600">{order.name}</p>
                    </div>
                    <div className="text-right">
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                        order.status === 'ready' ? 'bg-green-100 text-green-800' :
                        order.status === 'completed' ? 'bg-purple-100 text-purple-800' :
                        order.status === 'printing' ? 'bg-blue-100 text-blue-800' :
                        'bg-yellow-100 text-yellow-800'
                      }`}>
                        {getStatusSteps(order.status).find(step => step.active)?.label}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
};

export default OrderTracking;